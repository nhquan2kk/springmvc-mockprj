package com.springmvc.mock.controllers;

import java.io.IOException;
import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.springmvc.mock.models.Role;
import com.springmvc.mock.models.User;
import com.springmvc.mock.services.AdminRoleService;
import com.springmvc.mock.services.AdminUserService;


@Controller
@RequestMapping("/users")
public class AdminUserController {

	@Autowired
	private AdminUserService adminUserService;
	
	@Autowired
	private AdminRoleService adminRoleService;
	

	@GetMapping
	public String getAllUser(Model model) {
		List<User> users = adminUserService.getAllUser();
		List<Role> roles = adminRoleService.getAllRole();
		model.addAttribute("users", users);
		model.addAttribute("roles", roles);
		return "listUser";
	}
	
	@PostMapping("save")
	public String saveUser(@ModelAttribute("user") User user, 
	                       @RequestParam("avatarFile") MultipartFile file) throws IOException {
	    if (!file.isEmpty()) {
	        user.setAvatar(file.getBytes());
	    } else {
	        if (user.getId() != null) {
	            User existingUser = adminUserService.getUserById(user.getId());
	            if (existingUser != null) {
	                user.setAvatar(existingUser.getAvatar());
	            }
	        }
	    }
	    adminUserService.saveUser(user);
	    return "redirect:/users";
	}
	
	@GetMapping("/create")
	public String getCreateForm(Model model) {
	    List<Role> roles = adminRoleService.getAllRole();
	    model.addAttribute("roles", roles);  
	    model.addAttribute("user", new User());  
	    return "adminCreateUser";  
	}
	
	@PostMapping("/deluser")
	public String deleteUser(@RequestParam("id") Long id) {
		adminUserService.deleteUser(id);
		return "redirect:/user/listuser";
	}
	
	@PostMapping("/updateuser")
	public String updateUser(
			Model model,
	        @ModelAttribute User user
	        ) {
		List<Role> roles = adminRoleService.getAllRole();
	    model.addAttribute("roles", roles);
	    if (user != null) {
	        adminUserService.saveUser(user);
	    }
	    return "redirect:/user/listuser";
	}
}
